=== WC Multi Entrepôt ===
Contributors: jahdominemin
Tags: woocommerce, stock, entrepôt, warehouse, inventory
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.2
Stable tag: 3.1.0
License: GPLv2 or later

Gérez le stock de votre boutique WooCommerce par entrepôt, avec réapprovisionnement automatique entre entrepôts et historique complet.

== Description ==

* Aucun entrepôt préconfiguré : chaque site crée les siens depuis zéro. Entrepôts illimités : ajoutez, renommez, réordonnez ou supprimez vos entrepôts dans WooCommerce → Entrepôts, sans toucher au code.
* Un stock par entrepôt sur chaque fiche produit ; le stock global WooCommerce est calculé automatiquement (somme des entrepôts).
* Affectation d'un entrepôt à chaque commande : son stock diminue ; il est ajusté si vous modifiez les quantités, restitué en cas d'annulation ou de remboursement.
* Réapprovisionnement automatique : si un entrepôt manque de stock pour une commande, le manque est pris dans un autre entrepôt.
* Transfert manuel de stock entre entrepôts depuis la fiche produit.
* Colonnes de stock par entrepôt, filtre par entrepôt et niveau de stock dans la liste des produits.
* Historique complet des mouvements (qui, quand, avant / après, motif, commande) avec filtres et export CSV.
* Export / import CSV : colonnes « Stock <entrepôt> » avec l'export natif WooCommerce ; compatible avec les plugins d'import tiers (champs `_stock_<identifiant>`).

== Installation ==

1. Extensions → Ajouter → Téléverser une extension, choisissez le fichier .zip, puis Activer.
2. Après l'activation, vous arrivez sur WooCommerce → Entrepôts : saisissez le nom de vos entrepôts (un par ligne) et enregistrez.
3. Saisissez le stock de chaque entrepôt sur les fiches produit (onglet Inventaire).

WooCommerce doit être installé et actif.

== Changelog ==

= 3.1.0 =
* Le plugin ne contient plus d'entrepôts préinstallés : chaque site crée les siens.
* Assistant de première configuration (redirection à l'activation, rappel tant qu'aucun entrepôt n'existe, création de plusieurs entrepôts d'un coup).
* Les installations existantes avec « Douala » / « Yaoundé » sont migrées automatiquement sans perte.
* Prêt pour la traduction (dossier languages).

= 3.0.0 =
* Entrepôts illimités et page de réglages (WooCommerce → Entrepôts).
* Choix de l'entrepôt qui réapprovisionne, seuil de stock bas, conservation de l'historique, suppression des données à la désinstallation (optionnelle).
* Transfert manuel entre n'importe quels entrepôts.

= 2.x =
* Historique des mouvements, export/import, filtres, resynchronisation du stock global.
