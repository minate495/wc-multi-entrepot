<?php
/**
 * Désinstallation de WC Multi Entrepôt.
 *
 * Par défaut, les données (stocks par entrepôt, affectation des commandes, historique) sont CONSERVÉES.
 * Elles ne sont supprimées que si l'option « Supprimer aussi les stocks par entrepôt… »
 * a été cochée dans WooCommerce → Entrepôts → Réglages.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

if ( 'yes' === get_option( 'wcme_delete_on_uninstall', 'no' ) ) {
	global $wpdb;

	$warehouses = get_option( 'wcme_warehouses', array() );
	if ( is_array( $warehouses ) ) {
		foreach ( array_keys( $warehouses ) as $key ) {
			$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => '_stock_' . $key ) );
		}
	}

	// Affectation des commandes (stockage classique et stockage HPOS).
	foreach ( array( '_entrepot_choisi', '_entrepot_stock_reduit' ) as $meta_key ) {
		$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $meta_key ) );

		$hpos_meta = $wpdb->prefix . 'wc_orders_meta';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $hpos_meta ) ) === $hpos_meta ) {
			$wpdb->delete( $hpos_meta, array( 'meta_key' => $meta_key ) );
		}
	}
	$wpdb->delete( $wpdb->prefix . 'woocommerce_order_itemmeta', array( 'meta_key' => '_qty_stock_reduced' ) );

	$wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'wcme_stock_log' );

	foreach ( array( 'wcme_warehouses', 'wcme_db_version', 'wcme_auto_transfer', 'wcme_transfer_strategy', 'wcme_sync_global', 'wcme_low_threshold', 'wcme_retention_days', 'wcme_delete_on_uninstall' ) as $option ) {
		delete_option( $option );
	}
}

wp_clear_scheduled_hook( 'wcme_reconcile_cron' );
wp_clear_scheduled_hook( 'wcme_purge_cron' );
