<?php
/**
 * Plugin Name: WC Multi Entrepôt
 * Description: Gestion du stock par entrepôt pour WooCommerce : créez vos propres entrepôts (aucun entrepôt préconfiguré), affectation des commandes, réapprovisionnement automatique entre entrepôts, stock global synchronisé, historique des mouvements, export/import.
 * Version:     3.1.0
 * Author:      Jahdomine Minate
 * License:     GPL-2.0-or-later
 * Text Domain: wc-multi-entrepot
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.2
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) exit;

final class WC_Multi_Entrepot {

	/** Statuts pour lesquels on ne déduit pas le stock d'entrepôt. */
	const INACTIVE_STATUSES = array( 'cancelled', 'refunded', 'failed', 'trash', 'auto-draft', 'checkout-draft' );

	const DB_VERSION = '3';

	/** Mémoire de la liste des entrepôts (évite de relire l'option à chaque appel). */
	private $wh_cache = null;
	/** Vrai quand le plugin écrit lui-même les stocks d'entrepôt (évite les doubles traitements). */
	private $busy = false;
	/** Produits dont le stock global doit être recalculé en fin de requête. */
	private $pending_sync = array();
	/** Anciennes valeurs capturées avant une écriture externe (pour l'historique). */
	private $old_values = array();

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function load_textdomain() {
		load_plugin_textdomain( 'wc-multi-entrepot', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	public function init() {
		add_action( 'init', array( $this, 'load_textdomain' ) );

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', function () {
				echo '<div class="notice notice-error"><p>' . esc_html__( 'WC Multi Entrepôt nécessite que WooCommerce soit actif.', 'wc-multi-entrepot' ) . '</p></div>';
			} );
			return;
		}

		/* Table d'historique (créée à l'activation, ou ici si le fichier a simplement été remplacé) */
		if ( get_option( 'wcme_db_version' ) !== self::DB_VERSION ) {
			self::install();
		}

		/* Page « Entrepôts et réglages » + lien dans la liste des extensions */
		add_action( 'admin_menu', array( $this, 'add_settings_menu' ) );
		add_action( 'admin_post_wcme_save_warehouses', array( $this, 'handle_save_warehouses' ) );
		add_action( 'admin_post_wcme_save_settings', array( $this, 'handle_save_settings' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_links' ) );

		/* Première configuration : redirection après activation + rappel tant qu'aucun entrepôt n'existe */
		add_action( 'admin_init', array( $this, 'maybe_activation_redirect' ) );
		add_action( 'admin_notices', array( $this, 'setup_notice' ) );

		/* Historique des modifications de stock par entrepôt */
		add_action( 'admin_menu', array( $this, 'add_history_menu' ) );
		add_action( 'admin_init', array( $this, 'maybe_export_history' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_product_history_box' ) );

		/* Champs de stock par entrepôt sur la fiche produit */
		add_action( 'woocommerce_product_options_stock_fields', array( $this, 'add_warehouse_fields' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_warehouse_fields' ), 20 );
		add_action( 'admin_footer', array( $this, 'product_page_live_total_js' ) );

		/* Encart "Entrepôt" sur la commande. Priorité 50 : après l'enregistrement du statut par WooCommerce. */
		add_action( 'add_meta_boxes', array( $this, 'add_order_meta_box' ) );
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'save_order_meta_box' ), 50 );

		/* Commande réactivée (ex. annulée -> en cours) alors qu'un entrepôt est affecté */
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status_changed' ), 20, 4 );

		/* Annulation / remboursement : on restitue le stock de l'entrepôt */
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'restore_stock_on_order' ) );
		add_action( 'woocommerce_order_status_refunded', array( $this, 'restore_stock_on_order' ) );

		/* Modification des quantités / suppression d'un article dans la commande */
		add_action( 'woocommerce_saved_order_items', array( $this, 'adjust_stock_on_order_items_saved' ), 20, 2 );
		add_action( 'woocommerce_before_delete_order_item', array( $this, 'restore_stock_on_item_delete' ) );

		/* Écriture des stocks d'entrepôt par un AUTRE plugin (import, API, etc.) :
		 * on recalcule le stock global à la fin de la requête et on journalise. */
		add_action( 'update_post_meta', array( $this, 'capture_old_value' ), 10, 4 );
		add_action( 'update_postmeta', array( $this, 'capture_old_value' ), 10, 4 );
		add_action( 'added_post_meta', array( $this, 'on_external_meta_write' ), 10, 4 );
		add_action( 'updated_post_meta', array( $this, 'on_external_meta_write' ), 10, 4 );
		add_action( 'updated_postmeta', array( $this, 'on_external_meta_write' ), 10, 4 );
		add_action( 'shutdown', array( $this, 'flush_pending_syncs' ), 9999 ); // tout à la fin de la requête

		/* Resynchronisation manuelle (bouton) + vérification automatique toutes les heures */
		add_action( 'admin_post_wcme_resync', array( $this, 'handle_resync' ) );
		add_action( 'wcme_reconcile_cron', array( $this, 'cron_reconcile' ) );
		add_action( 'load-edit.php', array( $this, 'maybe_resync_on_products_screen' ) );
		if ( ! wp_next_scheduled( 'wcme_reconcile_cron' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'wcme_reconcile_cron' );
		}

		/* Purge automatique de l'historique (selon la durée de conservation choisie) */
		add_action( 'wcme_purge_cron', array( $this, 'cron_purge_history' ) );
		if ( ! wp_next_scheduled( 'wcme_purge_cron' ) ) {
			wp_schedule_event( time() + 600, 'daily', 'wcme_purge_cron' );
		}

		/* Export / import CSV natif de WooCommerce : une colonne "Stock <entrepôt>" par entrepôt */
		add_filter( 'woocommerce_product_export_column_names', array( $this, 'export_columns' ) );
		add_filter( 'woocommerce_product_export_product_default_columns', array( $this, 'export_columns' ) );
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			add_filter( 'woocommerce_product_export_product_column_stock_' . $wkey, array( $this, 'export_column_value' ), 10, 2 );
		}
		add_filter( 'woocommerce_csv_product_import_mapping_options', array( $this, 'import_mapping_options' ) );
		add_filter( 'woocommerce_csv_product_import_mapping_default_columns', array( $this, 'import_default_columns' ) );
		add_action( 'woocommerce_product_import_inserted_product_object', array( $this, 'import_warehouse_stock' ), 10, 2 );

		/* Une colonne de stock par entrepôt dans la liste des produits */
		add_filter( 'manage_edit-product_columns', array( $this, 'add_product_columns' ), 20 );
		add_action( 'manage_product_posts_custom_column', array( $this, 'render_product_column' ), 10, 2 );
		add_filter( 'manage_edit-product_sortable_columns', array( $this, 'sortable_product_columns' ) );
		add_action( 'pre_get_posts', array( $this, 'sort_products_by_warehouse' ) );
		add_action( 'restrict_manage_posts', array( $this, 'add_product_filters' ) );
		add_action( 'pre_get_posts', array( $this, 'filter_products_by_warehouse' ) );
		add_action( 'admin_head', array( $this, 'product_columns_css' ) );

		/* Colonne "Entrepôt" dans la liste des commandes (legacy + HPOS) */
		add_filter( 'manage_edit-shop_order_columns', array( $this, 'add_order_column' ) );
		add_action( 'manage_shop_order_posts_custom_column', array( $this, 'render_order_column' ), 10, 2 );
		add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'add_order_column' ) );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'render_order_column' ), 10, 2 );
	}

	private function order_screen_id() {
		return function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
	}

	/* =====================================================================
	 * RÉGLAGES
	 * ===================================================================== */

	/* =====================================================================
	 * 0) LISTE DES ENTREPÔTS ET RÉGLAGES (modifiables depuis WooCommerce → Entrepôts)
	 * ===================================================================== */

	/**
	 * Entrepôts : tableau identifiant => nom, dans l'ordre choisi par l'utilisateur.
	 * Vide tant que l'utilisateur n'en a pas créé : le plugin ne fournit aucun entrepôt d'office.
	 */
	private function warehouses() {
		if ( null === $this->wh_cache ) {
			$saved          = get_option( 'wcme_warehouses', array() );
			$this->wh_cache = is_array( $saved ) ? $saved : array();
		}
		return $this->wh_cache;
	}

	private function settings_url() {
		return admin_url( 'admin.php?page=wcme-settings' );
	}

	/** Après l'activation : on emmène directement l'utilisateur créer ses entrepôts. */
	public function maybe_activation_redirect() {
		if ( ! get_transient( 'wcme_activation_redirect' ) ) return;
		delete_transient( 'wcme_activation_redirect' );

		if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) ) return;
		if ( ! current_user_can( 'manage_woocommerce' ) || $this->warehouses() ) return;

		wp_safe_redirect( $this->settings_url() );
		exit;
	}

	/** Rappel affiché tant qu'aucun entrepôt n'a été créé. */
	public function setup_notice() {
		if ( $this->warehouses() || ! current_user_can( 'manage_woocommerce' ) ) return;

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( (string) $screen->id, 'wcme-settings' ) ) return;

		echo '<div class="notice notice-info"><p><strong>' . esc_html__( 'WC Multi Entrepôt', 'wc-multi-entrepot' ) . '</strong> — '
			. esc_html__( 'Aucun entrepôt n\'est encore configuré.', 'wc-multi-entrepot' ) . ' '
			. '<a href="' . esc_url( $this->settings_url() ) . '">' . esc_html__( 'Créer mes entrepôts', 'wc-multi-entrepot' ) . '</a></p></div>';
	}

	private function wh_exists( $key ) {
		$w = $this->warehouses();
		return ( is_string( $key ) && '' !== $key && isset( $w[ $key ] ) );
	}

	/** Nom affiché d'un entrepôt (l'identifiant si l'entrepôt a été supprimé depuis). */
	private function wh_label( $key ) {
		$w = $this->warehouses();
		return isset( $w[ $key ] ) ? $w[ $key ] : (string) $key;
	}

	/** Le stock global WooCommerce suit-il automatiquement la somme des entrepôts ? */
	private function sync_enabled() {
		return 'yes' === get_option( 'wcme_sync_global', 'yes' );
	}

	/** Seuil « stock bas » : réglage du plugin, sinon celui de WooCommerce. */
	private function low_threshold() {
		$v = get_option( 'wcme_low_threshold', '' );
		return ( '' !== $v ) ? (float) $v : (float) get_option( 'woocommerce_notify_low_stock_amount', 2 );
	}

	private function transfer_strategy() {
		return ( 'most' === get_option( 'wcme_transfer_strategy', 'order' ) ) ? 'most' : 'order';
	}

	/** Entrepôts pouvant fournir du stock à $warehouse, dans l'ordre où on les sollicite. */
	private function transfer_sources( $product_id, $warehouse ) {
		$list = $this->warehouses();
		unset( $list[ $warehouse ] );

		if ( 'most' === $this->transfer_strategy() ) {
			$stocks = array();
			foreach ( $list as $key => $label ) {
				$stocks[ $key ] = (float) get_post_meta( $product_id, '_stock_' . $key, true );
			}
			arsort( $stocks );
			$ordered = array();
			foreach ( $stocks as $key => $unused ) {
				$ordered[ $key ] = $list[ $key ];
			}
			return $ordered;
		}
		return $list;
	}

	private function auto_transfer_enabled() {
		return (bool) apply_filters( 'wcme_auto_transfer_enabled', 'yes' === get_option( 'wcme_auto_transfer', 'yes' ) );
	}

	/* =====================================================================
	 * 1) STOCK PAR ENTREPÔT SUR LA FICHE PRODUIT
	 * ===================================================================== */

	public function add_warehouse_fields() {
		global $post;

		if ( ! $this->warehouses() ) {
			echo '<div class="options_group show_if_simple show_if_variable"><p class="form-field"><em>'
				. esc_html__( 'Aucun entrepôt n\'est configuré.', 'wc-multi-entrepot' ) . ' '
				. '<a href="' . esc_url( $this->settings_url() ) . '">' . esc_html__( 'Créer mes entrepôts', 'wc-multi-entrepot' ) . '</a></em></p></div>';
			return;
		}

		echo '<div class="options_group show_if_simple show_if_variable">';

		foreach ( $this->warehouses() as $key => $label ) {
			woocommerce_wp_text_input( array(
				'id'                => '_stock_' . $key,
				'label'             => sprintf( __( 'Stock %s', 'wc-multi-entrepot' ), $label ),
				'desc_tip'          => true,
				'description'       => sprintf( __( 'Quantité disponible dans l\'entrepôt de %s.', 'wc-multi-entrepot' ), $label ),
				'type'              => 'number',
				'custom_attributes' => array( 'step' => '1', 'min' => '0' ),
				'value'             => get_post_meta( $post->ID, '_stock_' . $key, true ),
			) );
		}

		$wh_options = array( '' => __( '— Aucun —', 'wc-multi-entrepot' ) );
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$wh_options[ $wkey ] = $wlabel;
		}
		woocommerce_wp_select( array(
			'id'      => '_wcme_transfer_from',
			'label'   => __( 'Transfert : depuis', 'wc-multi-entrepot' ),
			'options' => $wh_options,
			'value'   => '',
		) );
		woocommerce_wp_select( array(
			'id'      => '_wcme_transfer_to',
			'label'   => __( 'Transfert : vers', 'wc-multi-entrepot' ),
			'options' => $wh_options,
			'value'   => '',
		) );
		woocommerce_wp_text_input( array(
			'id'                => '_wcme_transfer_qty',
			'label'             => __( 'Quantité à transférer', 'wc-multi-entrepot' ),
			'type'              => 'number',
			'custom_attributes' => array( 'step' => '1', 'min' => '0' ),
			'value'             => '',
		) );

		echo '<p class="form-field"><em>' . esc_html__( 'Le champ « Quantité en stock » (stock global) se met à jour automatiquement = somme des stocks des entrepôts.', 'wc-multi-entrepot' ) . '</em></p>';
		echo '</div>';
	}

	public function save_warehouse_fields( $post_id ) {
		$this->busy = true;
		// Modifications manuelles des stocks d'entrepôt (journalisées).
		foreach ( $this->warehouses() as $key => $label ) {
			$field = '_stock_' . $key;
			if ( isset( $_POST[ $field ] ) ) {
				$old = (float) get_post_meta( $post_id, $field, true );
				$new = (float) wc_stock_amount( wp_unslash( $_POST[ $field ] ) );
				update_post_meta( $post_id, $field, $new );
				$this->log_change( $post_id, $key, $old, $new, 'manual', 0, __( 'Modification sur la fiche produit', 'wc-multi-entrepot' ) );
			}
		}

		// Transfert manuel entre entrepôts.
		$from = isset( $_POST['_wcme_transfer_from'] ) ? sanitize_key( wp_unslash( $_POST['_wcme_transfer_from'] ) ) : '';
		$to   = isset( $_POST['_wcme_transfer_to'] ) ? sanitize_key( wp_unslash( $_POST['_wcme_transfer_to'] ) ) : '';
		$tq   = isset( $_POST['_wcme_transfer_qty'] ) ? wc_stock_amount( wp_unslash( $_POST['_wcme_transfer_qty'] ) ) : 0;
		if ( $tq > 0 && $this->wh_exists( $from ) && $this->wh_exists( $to ) && $from !== $to ) {
			$available = (float) get_post_meta( $post_id, '_stock_' . $from, true );
			$tq        = min( $tq, $available );
			if ( $tq > 0 ) {
				$to_old = (float) get_post_meta( $post_id, '_stock_' . $to, true );
				update_post_meta( $post_id, '_stock_' . $from, $available - $tq );
				update_post_meta( $post_id, '_stock_' . $to, $to_old + $tq );
				$this->log_change( $post_id, $from, $available, $available - $tq, 'transfer', 0, sprintf( __( 'Transfert vers %s', 'wc-multi-entrepot' ), $this->wh_label( $to ) ) );
				$this->log_change( $post_id, $to, $to_old, $to_old + $tq, 'transfer', 0, sprintf( __( 'Transfert depuis %s', 'wc-multi-entrepot' ), $this->wh_label( $from ) ) );
			}
		}

		// Mise à jour automatique du stock global = somme des stocks des entrepôts.
		$this->sync_global_stock( $post_id );
		$this->busy = false;
	}

	/**
	 * Stock global WooCommerce = somme des stocks des entrepôts.
	 * Appelé uniquement quand on enregistre la fiche produit (pas lors des commandes,
	 * où WooCommerce gère lui-même la déduction du stock global).
	 */
	private function sync_global_stock( $post_id ) {
		if ( ! $this->sync_enabled() ) return; // réglage : stock global géré à la main
		$filled = false;
		$total  = 0;
		foreach ( $this->warehouses() as $key => $label ) {
			$raw = get_post_meta( $post_id, '_stock_' . $key, true );
			if ( '' !== $raw ) $filled = true;
			$total += (float) $raw;
		}
		if ( ! $filled ) return; // aucun stock d'entrepôt saisi : on ne touche pas au stock global

		$product = wc_get_product( $post_id );
		if ( ! $product ) return;

		$product->set_manage_stock( true );
		$product->set_stock_quantity( $total );
		$product->save();
	}

	/**
	 * Sur la fiche produit : met à jour le champ « Quantité en stock » en direct
	 * pendant la saisie des stocks par entrepôt.
	 */
	public function product_page_live_total_js() {
		$screen = get_current_screen();
		if ( ! $screen || 'product' !== $screen->id || ! $this->sync_enabled() ) return;

		$selectors = array();
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$selectors[] = '#_stock_' . $wkey;
		}
		?>
		<script>
		jQuery( function ( $ ) {
			var $fields = $( <?php echo wp_json_encode( implode( ', ', $selectors ) ); ?> );
			if ( ! $fields.length ) return;

			function updateTotal() {
				var total = 0, filled = false;
				$fields.each( function () {
					if ( $( this ).val() !== '' ) filled = true;
					total += parseFloat( $( this ).val() ) || 0;
				} );
				if ( ! filled ) return;
				$( '#_manage_stock' ).prop( 'checked', true ).trigger( 'change' );
				$( '#_stock' ).val( total );
			}

			$fields.on( 'input change', updateTotal );
		} );
		</script>
		<?php
	}

	/* =====================================================================
	 * 2) AFFECTATION DE L'ENTREPÔT SUR LA COMMANDE
	 * ===================================================================== */

	public function add_order_meta_box() {
		add_meta_box(
			'wcme_entrepot_commande',
			__( 'Entrepôt d\'expédition', 'wc-multi-entrepot' ),
			array( $this, 'render_order_meta_box' ),
			$this->order_screen_id(),
			'side',
			'high'
		);
	}

	public function render_order_meta_box( $post_or_order ) {
		$order = ( $post_or_order instanceof WC_Order ) ? $post_or_order : wc_get_order( $post_or_order->ID );
		if ( ! $order ) return;

		if ( ! $this->warehouses() ) {
			echo '<p><a href="' . esc_url( $this->settings_url() ) . '">' . esc_html__( 'Créez d\'abord vos entrepôts', 'wc-multi-entrepot' ) . '</a></p>';
			return;
		}

		$current = $order->get_meta( '_entrepot_choisi' );
		$reduit  = $order->get_meta( '_entrepot_stock_reduit' );

		wp_nonce_field( 'wcme_save_entrepot', 'wcme_entrepot_nonce' );

		echo '<p><select name="wcme_entrepot" style="width:100%;">';
		echo '<option value="">' . esc_html__( '— Choisir —', 'wc-multi-entrepot' ) . '</option>';
		foreach ( $this->warehouses() as $key => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $key ), selected( $current, $key, false ), esc_html( $label ) );
		}
		if ( $current && ! $this->wh_exists( $current ) ) {
			printf( '<option value="%s" selected>%s</option>', esc_attr( $current ), esc_html( sprintf( __( '%s (supprimé)', 'wc-multi-entrepot' ), $current ) ) );
		}
		echo '</select></p>';

		if ( 'yes' === $reduit ) {
			echo '<p style="color:#2271b1;"><strong>' . esc_html__( 'Stock de l\'entrepôt déjà déduit pour cette commande.', 'wc-multi-entrepot' ) . '</strong></p>';
		} else {
			echo '<p style="color:#996800;">' . esc_html__( 'Le stock de l\'entrepôt sera déduit dès que vous enregistrez la commande avec un entrepôt choisi.', 'wc-multi-entrepot' ) . '</p>';
		}
	}

	public function save_order_meta_box( $order_id ) {
		if ( ! isset( $_POST['wcme_entrepot_nonce'] ) || ! wp_verify_nonce( $_POST['wcme_entrepot_nonce'], 'wcme_save_entrepot' ) ) {
			return;
		}
		if ( ! isset( $_POST['wcme_entrepot'] ) ) return;

		$order = wc_get_order( $order_id );
		if ( ! $order ) return;

		$new_warehouse = sanitize_key( $_POST['wcme_entrepot'] );
		if ( $new_warehouse && ! $this->wh_exists( $new_warehouse ) ) return;

		$old_warehouse   = $order->get_meta( '_entrepot_choisi' );
		$already_reduced = 'yes' === $order->get_meta( '_entrepot_stock_reduit' );

		// Changement d'entrepôt alors que le stock était déjà déduit : on restitue l'ancien.
		if ( $new_warehouse !== $old_warehouse && $already_reduced ) {
			$this->restore_stock_on_order( $order );
			$order = wc_get_order( $order_id );
		}

		$order->update_meta_data( '_entrepot_choisi', $new_warehouse );
		$order->save();

		// Déduction du stock du (nouvel) entrepôt affecté.
		if ( $new_warehouse ) {
			$this->deduct_stock_on_order( $order );
		}
	}

	/* =====================================================================
	 * 3) DÉDUCTION / RESTAURATION DU STOCK DE L'ENTREPÔT
	 * ===================================================================== */

	/**
	 * Déduit le stock de l'entrepôt affecté. Le stock global n'est PAS touché (WooCommerce s'en charge).
	 */
	private function deduct_stock_on_order( $order ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
		if ( ! $order ) return;

		if ( 'yes' === $order->get_meta( '_entrepot_stock_reduit' ) ) return;
		if ( in_array( $order->get_status(), self::INACTIVE_STATUSES, true ) ) return;

		$warehouse = $order->get_meta( '_entrepot_choisi' );
		if ( ! $warehouse || ! $this->wh_exists( $warehouse ) ) return;

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) continue;

			$qty = (float) $item->get_quantity();
			$this->change_warehouse_stock( $item->get_product_id(), $warehouse, -$qty, $order, 'order_deduct' );
			wc_update_order_item_meta( $item_id, '_qty_stock_reduced', $qty );
		}

		$order->update_meta_data( '_entrepot_stock_reduit', 'yes' );
		$order->save();
		$order->add_order_note( sprintf( __( 'WC Multi Entrepôt : stock déduit de l\'entrepôt %s.', 'wc-multi-entrepot' ), $this->wh_label( $warehouse ) ) );
	}

	public function restore_stock_on_order( $order ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
		if ( ! $order ) return;

		if ( 'yes' !== $order->get_meta( '_entrepot_stock_reduit' ) ) return;

		$warehouse = $order->get_meta( '_entrepot_choisi' );
		if ( ! $warehouse || ! $this->wh_exists( $warehouse ) ) return;

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) continue;

			$qty_reduced = (float) wc_get_order_item_meta( $item_id, '_qty_stock_reduced', true );
			if ( $qty_reduced <= 0 ) continue;

			$this->change_warehouse_stock( $item->get_product_id(), $warehouse, $qty_reduced, $order, 'order_restore' );
			wc_update_order_item_meta( $item_id, '_qty_stock_reduced', 0 );
		}

		$order->update_meta_data( '_entrepot_stock_reduit', 'no' );
		$order->save();
		$order->add_order_note( sprintf( __( 'WC Multi Entrepôt : stock restauré dans l\'entrepôt %s.', 'wc-multi-entrepot' ), $this->wh_label( $warehouse ) ) );
	}

	/**
	 * Commande réactivée (ex. annulée -> en cours) avec un entrepôt déjà affecté : on redéduit.
	 */
	public function on_status_changed( $order_id, $from, $to, $order ) {
		if ( in_array( $to, self::INACTIVE_STATUSES, true ) ) return;
		$this->deduct_stock_on_order( $order_id );
	}

	/* =====================================================================
	 * 4) MODIFICATION DES QUANTITÉS DANS LA COMMANDE
	 * ===================================================================== */

	public function adjust_stock_on_order_items_saved( $order_id, $items ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) return;

		if ( 'yes' !== $order->get_meta( '_entrepot_stock_reduit' ) ) return;

		$warehouse = $order->get_meta( '_entrepot_choisi' );
		if ( ! $warehouse || ! $this->wh_exists( $warehouse ) ) return;

		$modifie = false;

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) continue;

			$new_qty         = (float) $item->get_quantity();
			$qty_deja_reduit = (float) wc_get_order_item_meta( $item_id, '_qty_stock_reduced', true );
			$delta           = $new_qty - $qty_deja_reduit; // > 0 : quantité augmentée, < 0 : diminuée

			if ( 0.0 === $delta ) continue;

			$this->change_warehouse_stock( $item->get_product_id(), $warehouse, -$delta, $order, 'order_adjust' );
			wc_update_order_item_meta( $item_id, '_qty_stock_reduced', $new_qty );
			$modifie = true;
		}

		if ( $modifie ) {
			$order->add_order_note( sprintf( __( 'WC Multi Entrepôt : quantités modifiées, stock de l\'entrepôt %s mis à jour.', 'wc-multi-entrepot' ), $this->wh_label( $warehouse ) ) );
		}
	}

	/**
	 * Un article est supprimé de la commande : on restitue sa quantité à l'entrepôt.
	 */
	public function restore_stock_on_item_delete( $item_id ) {
		$item = WC_Order_Factory::get_order_item( $item_id );
		if ( ! $item instanceof WC_Order_Item_Product ) return;

		$order = wc_get_order( $item->get_order_id() );
		if ( ! $order || 'yes' !== $order->get_meta( '_entrepot_stock_reduit' ) ) return;

		$warehouse = $order->get_meta( '_entrepot_choisi' );
		if ( ! $warehouse || ! $this->wh_exists( $warehouse ) ) return;

		$qty_reduced = (float) wc_get_order_item_meta( $item_id, '_qty_stock_reduced', true );
		if ( $qty_reduced > 0 ) {
			$this->change_warehouse_stock( $item->get_product_id(), $warehouse, $qty_reduced, $order, 'item_delete' );
			$order->add_order_note( sprintf( __( 'WC Multi Entrepôt : article supprimé, %1$s unité(s) restituée(s) à l\'entrepôt %2$s.', 'wc-multi-entrepot' ), wc_format_decimal( $qty_reduced ), $this->wh_label( $warehouse ) ) );
		}
	}

	/* =====================================================================
	 * 5) MOUVEMENT DE STOCK D'UN ENTREPÔT (avec réapprovisionnement auto)
	 * ===================================================================== */

	/**
	 * delta positif = ajout, négatif = retrait. Si le retrait dépasse le stock de l'entrepôt,
	 * le manque est pris dans l'autre entrepôt (si l'option est activée).
	 * Chaque mouvement est inscrit dans l'historique.
	 */
	private function change_warehouse_stock( $product_id, $warehouse, $delta, $order = null, $reason = 'order_deduct' ) {
		$this->busy = true;
		$meta_key   = '_stock_' . $warehouse;
		$current    = (float) get_post_meta( $product_id, $meta_key, true );
		$order_id   = ( $order instanceof WC_Order ) ? $order->get_id() : 0;

		if ( $delta < 0 && ( $current + $delta ) < 0 && $this->auto_transfer_enabled() ) {
			$shortfall = -( $current + $delta );

			foreach ( $this->transfer_sources( $product_id, $warehouse ) as $other => $other_label ) {
				if ( $other === $warehouse || $shortfall <= 0 ) continue;

				$other_key = '_stock_' . $other;
				$available = (float) get_post_meta( $product_id, $other_key, true );
				$take      = min( $available, $shortfall );

				if ( $take > 0 ) {
					update_post_meta( $product_id, $other_key, $available - $take );
					$this->log_change( $product_id, $other, $available, $available - $take, 'auto_transfer', $order_id, sprintf( __( 'Réapprovisionnement automatique vers %s', 'wc-multi-entrepot' ), $this->wh_label( $warehouse ) ) );
					$this->log_change( $product_id, $warehouse, $current, $current + $take, 'auto_transfer', $order_id, sprintf( __( 'Réapprovisionnement automatique depuis %s', 'wc-multi-entrepot' ), $other_label ) );

					$current   += $take;
					$shortfall -= $take;

					if ( $order instanceof WC_Order ) {
						$order->add_order_note( sprintf(
							__( 'WC Multi Entrepôt : réapprovisionnement automatique de %1$s unité(s) de « %2$s » depuis %3$s vers %4$s.', 'wc-multi-entrepot' ),
							wc_format_decimal( $take ),
							get_the_title( $product_id ),
							$other_label,
							$this->wh_label( $warehouse )
						) );
					}
				}
			}

			if ( $shortfall > 0 && $order instanceof WC_Order ) {
				$order->add_order_note( sprintf(
					__( 'WC Multi Entrepôt : stock total des entrepôts insuffisant pour « %1$s » (%2$s unité(s) manquantes).', 'wc-multi-entrepot' ),
					get_the_title( $product_id ),
					wc_format_decimal( $shortfall )
				) );
			}
		}

		$new_qty = $current + $delta;
		if ( $new_qty < 0 ) $new_qty = 0;

		update_post_meta( $product_id, $meta_key, $new_qty );
		$this->log_change( $product_id, $warehouse, $current, $new_qty, $reason, $order_id );
		$this->busy = false;
	}

	/* =====================================================================
	 * 5b) HISTORIQUE DES MODIFICATIONS DE STOCK
	 * ===================================================================== */

	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'wcme_stock_log';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();

		dbDelta( "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			product_id bigint(20) unsigned NOT NULL,
			warehouse varchar(20) NOT NULL,
			old_qty decimal(18,4) NOT NULL DEFAULT 0,
			new_qty decimal(18,4) NOT NULL DEFAULT 0,
			delta decimal(18,4) NOT NULL DEFAULT 0,
			reason varchar(40) NOT NULL DEFAULT '',
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			note text,
			PRIMARY KEY  (id),
			KEY product_id (product_id),
			KEY warehouse (warehouse),
			KEY created_at (created_at)
		) {$charset};" );

		// Aucun entrepôt n'est créé d'office : chaque site crée les siens.
		// Migration : avant la 3.1, « Douala » et « Yaoundé » étaient intégrés au code. Si la liste n'a
		// jamais été enregistrée mais que des stocks existent pour eux, on les conserve pour ne rien perdre.
		if ( false === get_option( 'wcme_warehouses', false ) ) {
			$initial = array();
			$legacy  = array( 'douala' => 'Douala', 'yaounde' => 'Yaoundé' );
			foreach ( array_keys( $legacy ) as $legacy_key ) {
				if ( $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key = %s LIMIT 1", '_stock_' . $legacy_key ) ) ) {
					$initial = $legacy;
					break;
				}
			}
			add_option( 'wcme_warehouses', $initial );
		}

		update_option( 'wcme_db_version', self::DB_VERSION );
	}

	/** Activation : installation + redirection vers la page de création des entrepôts. */
	public static function on_activate() {
		self::install();
		set_transient( 'wcme_activation_redirect', 1, 60 );
	}

	/**
	 * Enregistre un mouvement de stock : qui (utilisateur connecté, 0 = système/client), quand (UTC), quoi.
	 */
	private function log_change( $product_id, $warehouse, $old, $new, $reason, $order_id = 0, $note = '' ) {
		global $wpdb;

		$old = (float) $old;
		$new = (float) $new;
		if ( $old === $new ) return;

		$wpdb->insert(
			self::table(),
			array(
				'created_at' => gmdate( 'Y-m-d H:i:s' ),
				'user_id'    => get_current_user_id(),
				'product_id' => (int) $product_id,
				'warehouse'  => $warehouse,
				'old_qty'    => $old,
				'new_qty'    => $new,
				'delta'      => $new - $old,
				'reason'     => $reason,
				'order_id'   => (int) $order_id,
				'note'       => $note,
			),
			array( '%s', '%d', '%d', '%s', '%f', '%f', '%f', '%s', '%d', '%s' )
		);
	}

	private function reason_labels() {
		return array(
			'manual'        => __( 'Modification manuelle', 'wc-multi-entrepot' ),
			'transfer'      => __( 'Transfert manuel', 'wc-multi-entrepot' ),
			'auto_transfer' => __( 'Réapprovisionnement auto', 'wc-multi-entrepot' ),
			'order_deduct'  => __( 'Commande : déduction', 'wc-multi-entrepot' ),
			'order_restore' => __( 'Commande : restitution', 'wc-multi-entrepot' ),
			'order_adjust'  => __( 'Commande : quantité modifiée', 'wc-multi-entrepot' ),
			'item_delete'   => __( 'Commande : article supprimé', 'wc-multi-entrepot' ),
			'import'        => __( 'Import CSV', 'wc-multi-entrepot' ),
			'external'      => __( 'Modification externe (import / autre plugin)', 'wc-multi-entrepot' ),
		);
	}

	/** Filtres de l'écran d'historique (lus dans l'URL). */
	private function history_filters() {
		return array(
			'warehouse' => isset( $_GET['warehouse'] ) ? sanitize_key( $_GET['warehouse'] ) : '',
			'user'      => ( isset( $_GET['user'] ) && '' !== $_GET['user'] ) ? (string) absint( $_GET['user'] ) : '',
			'product'   => isset( $_GET['product_q'] ) ? sanitize_text_field( wp_unslash( $_GET['product_q'] ) ) : '',
			'from'      => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
			'to'        => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
		);
	}

	private function history_query( $f, $limit = 0, $offset = 0, $product_id = 0 ) {
		global $wpdb;

		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $product_id ) {
			$where[]  = 'l.product_id = %d';
			$params[] = $product_id;
		}
		if ( $f['warehouse'] && $this->wh_exists( $f['warehouse'] ) ) {
			$where[]  = 'l.warehouse = %s';
			$params[] = $f['warehouse'];
		}
		if ( '' !== $f['user'] ) {
			$where[]  = 'l.user_id = %d';
			$params[] = (int) $f['user'];
		}
		if ( '' !== $f['product'] ) {
			$where[]  = '(p.post_title LIKE %s OR l.product_id = %d)';
			$params[] = '%' . $wpdb->esc_like( $f['product'] ) . '%';
			$params[] = absint( $f['product'] );
		}
		if ( $f['from'] && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $f['from'] ) ) {
			$where[]  = 'l.created_at >= %s';
			$params[] = get_gmt_from_date( $f['from'] . ' 00:00:00' );
		}
		if ( $f['to'] && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $f['to'] ) ) {
			$where[]  = 'l.created_at <= %s';
			$params[] = get_gmt_from_date( $f['to'] . ' 23:59:59' );
		}

		$where_sql = implode( ' AND ', $where );
		$from_sql  = "FROM {$table} l
			LEFT JOIN {$wpdb->posts} p ON p.ID = l.product_id
			LEFT JOIN {$wpdb->users} u ON u.ID = l.user_id
			WHERE {$where_sql}";

		$count_sql = "SELECT COUNT(*) {$from_sql}";
		$rows_sql  = "SELECT l.*, p.post_title, u.display_name {$from_sql} ORDER BY l.id DESC";

		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );

		if ( $limit ) {
			$rows_sql .= ' LIMIT %d OFFSET %d';
			$params[]  = $limit;
			$params[]  = $offset;
		}
		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $rows_sql, $params ) ) : $wpdb->get_results( $rows_sql );

		return array( $rows, $total );
	}

	private function format_log_date( $utc ) {
		return wp_date( 'd/m/Y H:i:s', strtotime( $utc . ' UTC' ) );
	}

	private function log_user_label( $row ) {
		if ( (int) $row->user_id === 0 ) {
			return __( 'Système / client', 'wc-multi-entrepot' );
		}
		return $row->display_name ? $row->display_name : sprintf( __( 'Utilisateur #%d (supprimé)', 'wc-multi-entrepot' ), $row->user_id );
	}

	/** Tableau HTML de l'historique. */
	private function render_log_table( $rows, $show_product = true ) {
		$reasons = $this->reason_labels();

		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'Aucune modification enregistrée.', 'wc-multi-entrepot' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'Date et heure', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Utilisateur', 'wc-multi-entrepot' ) . '</th>';
		if ( $show_product ) echo '<th>' . esc_html__( 'Produit', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Entrepôt', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Avant', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Après', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Variation', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Motif', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Commande', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Détail', 'wc-multi-entrepot' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $r ) {
			$delta = (float) $r->delta;
			$color = $delta > 0 ? '#007017' : '#b32d2e';

			echo '<tr>';
			echo '<td>' . esc_html( $this->format_log_date( $r->created_at ) ) . '</td>';
			echo '<td>' . esc_html( $this->log_user_label( $r ) ) . '</td>';

			if ( $show_product ) {
				$title = $r->post_title ? $r->post_title : '#' . $r->product_id;
				$link  = get_edit_post_link( $r->product_id );
				echo '<td>' . ( $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a>' : esc_html( $title ) ) . '</td>';
			}

			echo '<td>' . esc_html( $this->wh_exists( $r->warehouse ) ? $this->wh_label( $r->warehouse ) : $r->warehouse ) . '</td>';
			echo '<td>' . esc_html( wc_format_decimal( $r->old_qty ) ) . '</td>';
			echo '<td>' . esc_html( wc_format_decimal( $r->new_qty ) ) . '</td>';
			echo '<td style="color:' . esc_attr( $color ) . ';font-weight:600;">' . esc_html( ( $delta > 0 ? '+' : '' ) . wc_format_decimal( $delta ) ) . '</td>';
			echo '<td>' . esc_html( isset( $reasons[ $r->reason ] ) ? $reasons[ $r->reason ] : $r->reason ) . '</td>';

			echo '<td>';
			if ( $r->order_id ) {
				$order = wc_get_order( $r->order_id );
				if ( $order ) {
					echo '<a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a>';
				} else {
					echo '#' . esc_html( $r->order_id );
				}
			} else {
				echo '—';
			}
			echo '</td>';

			echo '<td>' . esc_html( $r->note ) . '</td>';
			echo '</tr>';
		}

		echo '</tbody></table>';
	}

	public function add_history_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Historique des entrepôts', 'wc-multi-entrepot' ),
			__( 'Historique entrepôts', 'wc-multi-entrepot' ),
			'manage_woocommerce',
			'wcme-history',
			array( $this, 'render_history_page' )
		);
	}

	public function render_history_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) return;

		global $wpdb;

		$f        = $this->history_filters();
		$per_page = 50;
		$paged    = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 );

		list( $rows, $total ) = $this->history_query( $f, $per_page, ( $paged - 1 ) * $per_page );

		// Utilisateurs présents dans l'historique (pour le filtre).
		$user_ids = $wpdb->get_col( 'SELECT DISTINCT user_id FROM ' . self::table() . ' ORDER BY user_id' );

		$export_url = wp_nonce_url(
			add_query_arg( array_merge( array( 'page' => 'wcme-history', 'wcme_export' => 1, 'product_q' => $f['product'] ), array_diff_key( $f, array( 'product' => 1 ) ) ), admin_url( 'admin.php' ) ),
			'wcme_export'
		);

		echo '<div class="wrap"><h1>' . esc_html__( 'Historique des stocks par entrepôt', 'wc-multi-entrepot' ) . '</h1>';

		if ( isset( $_GET['wcme_resynced'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( __( 'Resynchronisation terminée : %d produit(s) mis à jour.', 'wc-multi-entrepot' ), absint( $_GET['wcme_resynced'] ) ) ) . '</p></div>';
		}

		$mismatch = count( $this->find_mismatched_products() );
		echo '<div class="notice ' . ( $mismatch ? 'notice-warning' : 'notice-info' ) . ' inline" style="padding:10px 12px;">';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">';
		echo '<input type="hidden" name="action" value="wcme_resync">';
		wp_nonce_field( 'wcme_resync' );
		echo '<span>' . ( $mismatch
			? esc_html( sprintf( __( '%d produit(s) ont un stock global différent de la somme des entrepôts.', 'wc-multi-entrepot' ), $mismatch ) )
			: esc_html__( 'Le stock global de tous les produits correspond à la somme des entrepôts.', 'wc-multi-entrepot' ) ) . '</span>';
		echo '<button class="button button-secondary">' . esc_html__( 'Resynchroniser le stock global de tous les produits', 'wc-multi-entrepot' ) . '</button>';
		echo '</form></div>';

		echo '<form method="get" style="margin:12px 0;">';
		echo '<input type="hidden" name="page" value="wcme-history">';

		echo '<select name="warehouse"><option value="">' . esc_html__( 'Tous les entrepôts', 'wc-multi-entrepot' ) . '</option>';
		foreach ( $this->warehouses() as $key => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $key ), selected( $f['warehouse'], $key, false ), esc_html( $label ) );
		}
		echo '</select> ';

		echo '<select name="user"><option value="">' . esc_html__( 'Tous les utilisateurs', 'wc-multi-entrepot' ) . '</option>';
		foreach ( $user_ids as $uid ) {
			$uid  = (int) $uid;
			$name = $uid ? ( get_userdata( $uid ) ? get_userdata( $uid )->display_name : '#' . $uid ) : __( 'Système / client', 'wc-multi-entrepot' );
			printf( '<option value="%d" %s>%s</option>', $uid, selected( $f['user'], (string) $uid, false ), esc_html( $name ) );
		}
		echo '</select> ';

		printf( '<input type="search" name="product_q" value="%s" placeholder="%s"> ', esc_attr( $f['product'] ), esc_attr__( 'Produit (nom ou ID)', 'wc-multi-entrepot' ) );
		printf( '<label>%s <input type="date" name="from" value="%s"></label> ', esc_html__( 'Du', 'wc-multi-entrepot' ), esc_attr( $f['from'] ) );
		printf( '<label>%s <input type="date" name="to" value="%s"></label> ', esc_html__( 'Au', 'wc-multi-entrepot' ), esc_attr( $f['to'] ) );

		echo '<button class="button button-primary">' . esc_html__( 'Filtrer', 'wc-multi-entrepot' ) . '</button> ';
		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=wcme-history' ) ) . '">' . esc_html__( 'Réinitialiser', 'wc-multi-entrepot' ) . '</a> ';
		echo '<a class="button" href="' . esc_url( $export_url ) . '">' . esc_html__( 'Exporter en CSV', 'wc-multi-entrepot' ) . '</a>';
		echo '</form>';

		echo '<p>' . sprintf( esc_html__( '%d mouvement(s) trouvé(s).', 'wc-multi-entrepot' ), $total ) . '</p>';

		$this->render_log_table( $rows, true );

		$pages = (int) ceil( $total / $per_page );
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array(
				'base'      => add_query_arg( 'paged', '%#%' ),
				'format'    => '',
				'current'   => $paged,
				'total'     => $pages,
				'prev_text' => '‹',
				'next_text' => '›',
			) ) ) . '</div></div>';
		}

		echo '</div>';
	}

	public function maybe_export_history() {
		if ( ! isset( $_GET['page'], $_GET['wcme_export'] ) || 'wcme-history' !== $_GET['page'] ) return;
		if ( ! current_user_can( 'manage_woocommerce' ) || ! wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '', 'wcme_export' ) ) {
			wp_die( esc_html__( 'Accès refusé.', 'wc-multi-entrepot' ) );
		}

		list( $rows ) = $this->history_query( $this->history_filters() );
		$reasons      = $this->reason_labels();

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=historique-entrepots-' . gmdate( 'Y-m-d' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // BOM UTF-8 pour Excel
		fputcsv( $out, array( 'Date et heure', 'Utilisateur', 'Produit', 'Entrepôt', 'Avant', 'Après', 'Variation', 'Motif', 'Commande', 'Détail' ), ';' );

		foreach ( $rows as $r ) {
			fputcsv( $out, array(
				$this->format_log_date( $r->created_at ),
				$this->log_user_label( $r ),
				$r->post_title ? $r->post_title : '#' . $r->product_id,
				$this->wh_exists( $r->warehouse ) ? $this->wh_label( $r->warehouse ) : $r->warehouse,
				$r->old_qty + 0,
				$r->new_qty + 0,
				$r->delta + 0,
				isset( $reasons[ $r->reason ] ) ? $reasons[ $r->reason ] : $r->reason,
				$r->order_id ? $r->order_id : '',
				$r->note,
			), ';' );
		}
		fclose( $out );
		exit;
	}

	/** Encart "Historique" sur la fiche produit (20 derniers mouvements). */
	public function add_product_history_box() {
		add_meta_box(
			'wcme_product_history',
			__( 'Historique des stocks par entrepôt', 'wc-multi-entrepot' ),
			array( $this, 'render_product_history_box' ),
			'product',
			'normal',
			'low'
		);
	}

	public function render_product_history_box( $post ) {
		$empty = array( 'warehouse' => '', 'user' => '', 'product' => '', 'from' => '', 'to' => '' );
		list( $rows, $total ) = $this->history_query( $empty, 20, 0, (int) $post->ID );

		$this->render_log_table( $rows, false );

		if ( $total > 20 ) {
			$url = add_query_arg( array( 'page' => 'wcme-history', 'product_q' => $post->ID ), admin_url( 'admin.php' ) );
			echo '<p><a href="' . esc_url( $url ) . '">' . esc_html__( 'Voir tout l\'historique de ce produit', 'wc-multi-entrepot' ) . '</a></p>';
		}
	}

	/* =====================================================================
	 * 7) COLONNES DE STOCK PAR ENTREPÔT DANS LA LISTE DES PRODUITS
	 * ===================================================================== */

	/** Entrepôt sélectionné dans le filtre de la liste des produits ('' si aucun). */
	private function selected_warehouse() {
		$w = isset( $_GET['wcme_warehouse'] ) ? sanitize_key( wp_unslash( $_GET['wcme_warehouse'] ) ) : '';
		return ( $w && $this->wh_exists( $w ) ) ? $w : '';
	}

	private function selected_level() {
		$l = isset( $_GET['wcme_level'] ) ? sanitize_key( wp_unslash( $_GET['wcme_level'] ) ) : '';
		return in_array( $l, array( 'in', 'low', 'out' ), true ) ? $l : '';
	}

	public function add_product_columns( $columns ) {
		$only = $this->selected_warehouse(); // si un entrepôt est filtré, on n'affiche que sa colonne

		$new   = array();
		$added = false;
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'is_in_stock' === $key ) {
				foreach ( $this->warehouses() as $wkey => $wlabel ) {
					if ( $only && $only !== $wkey ) continue;
					$new[ 'wcme_stock_' . $wkey ] = sprintf( __( 'Stock %s', 'wc-multi-entrepot' ), $wlabel );
				}
				$added = true;
			}
		}
		// Si la colonne "Stock" n'existe pas, on ajoute à la fin.
		if ( ! $added ) {
			foreach ( $this->warehouses() as $wkey => $wlabel ) {
				if ( $only && $only !== $wkey ) continue;
				$new[ 'wcme_stock_' . $wkey ] = sprintf( __( 'Stock %s', 'wc-multi-entrepot' ), $wlabel );
			}
		}
		return $new;
	}

	/** Listes déroulantes de filtre au-dessus du tableau des produits. */
	public function add_product_filters( $post_type ) {
		if ( 'product' !== $post_type ) return;

		$w = $this->selected_warehouse();
		$l = $this->selected_level();

		echo '<select name="wcme_warehouse">';
		echo '<option value="">' . esc_html__( 'Tous les entrepôts', 'wc-multi-entrepot' ) . '</option>';
		foreach ( $this->warehouses() as $key => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $key ), selected( $w, $key, false ), esc_html( sprintf( __( 'Entrepôt : %s', 'wc-multi-entrepot' ), $label ) ) );
		}
		echo '</select>';

		$levels = array(
			''    => __( 'Tous les niveaux de stock', 'wc-multi-entrepot' ),
			'in'  => __( 'En stock (supérieur à 0)', 'wc-multi-entrepot' ),
			'low' => __( 'Stock bas', 'wc-multi-entrepot' ),
			'out' => __( 'En rupture (0 ou vide)', 'wc-multi-entrepot' ),
		);
		echo '<select name="wcme_level">';
		foreach ( $levels as $key => $label ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $key ), selected( $l, $key, false ), esc_html( $label ) );
		}
		echo '</select>';
	}

	/** Condition de stock pour un entrepôt donné. */
	private function level_clause( $wkey, $level ) {
		$key = '_stock_' . $wkey;
		$low = $this->low_threshold();

		switch ( $level ) {
			case 'in':
				return array( 'key' => $key, 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC' );
			case 'low':
				return array(
					'relation' => 'AND',
					array( 'key' => $key, 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC' ),
					array( 'key' => $key, 'value' => $low, 'compare' => '<=', 'type' => 'NUMERIC' ),
				);
			default: // 'out'
				return array(
					'relation' => 'OR',
					array( 'key' => $key, 'compare' => 'NOT EXISTS' ),
					array( 'key' => $key, 'value' => '', 'compare' => '=' ),
					array( 'key' => $key, 'value' => 0, 'compare' => '<=', 'type' => 'NUMERIC' ),
				);
		}
	}

	/**
	 * Applique le filtre : niveau de stock dans l'entrepôt choisi.
	 * Sans entrepôt choisi, le niveau s'applique à « au moins un entrepôt ».
	 */
	public function filter_products_by_warehouse( $query ) {
		global $pagenow;
		if ( ! is_admin() || 'edit.php' !== $pagenow || ! $query->is_main_query() ) return;
		if ( 'product' !== $query->get( 'post_type' ) ) return;

		$level = $this->selected_level();
		if ( '' === $level ) return; // seul l'entrepôt est choisi : tous les produits, une seule colonne

		$w       = $this->selected_warehouse();
		$targets = $w ? array( $w ) : array_keys( $this->warehouses() );

		$group = array( 'relation' => 'OR' );
		foreach ( $targets as $wkey ) {
			$group[] = $this->level_clause( $wkey, $level );
		}

		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = $group;
		$query->set( 'meta_query', $meta_query );
	}

	public function render_product_column( $column, $post_id ) {
		if ( 0 !== strpos( $column, 'wcme_stock_' ) ) return;

		$wkey = substr( $column, strlen( 'wcme_stock_' ) );
		if ( ! $this->wh_exists( $wkey ) ) return;

		$raw = get_post_meta( $post_id, '_stock_' . $wkey, true );
		if ( '' === $raw ) {
			echo '<span aria-hidden="true">—</span>';
			return;
		}

		$qty   = (float) $raw;
		$class = $qty <= 0 ? 'wcme-out' : ( $qty <= $this->low_threshold() ? 'wcme-low' : 'wcme-ok' );
		echo '<span class="wcme-qty ' . esc_attr( $class ) . '">' . esc_html( wc_format_decimal( $qty ) ) . '</span>';
	}

	public function sortable_product_columns( $columns ) {
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$columns[ 'wcme_stock_' . $wkey ] = 'wcme_stock_' . $wkey;
		}
		return $columns;
	}

	public function sort_products_by_warehouse( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() ) return;

		$orderby = $query->get( 'orderby' );
		if ( is_string( $orderby ) && 0 === strpos( $orderby, 'wcme_stock_' ) ) {
			$wkey = substr( $orderby, strlen( 'wcme_stock_' ) );
			if ( $this->wh_exists( $wkey ) ) {
				$query->set( 'meta_key', '_stock_' . $wkey );
				$query->set( 'orderby', 'meta_value_num' );
			}
		}
	}

	public function product_columns_css() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'edit-product' !== $screen->id ) return;
		echo '<style>
			[class*="column-wcme_stock_"] { width: 9%; }
			.wcme-qty { font-weight: 600; }
			.wcme-ok  { color: #007017; }
			.wcme-low { color: #b26200; }
			.wcme-out { color: #b32d2e; }
		</style>';
	}

	/* =====================================================================
	 * 8) EXPORT / IMPORT CSV NATIF WOOCOMMERCE
	 * ===================================================================== */

	/** Ajoute une colonne "Stock <entrepôt>" par entrepôt à l'export des produits. */
	public function export_columns( $columns ) {
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$columns[ 'stock_' . $wkey ] = sprintf( __( 'Stock %s', 'wc-multi-entrepot' ), $wlabel );
		}
		return $columns;
	}

	public function export_column_value( $value, $product ) {
		// Le stock par entrepôt est suivi au niveau du produit parent (pas des variations).
		if ( $product->get_parent_id() ) return '';

		$filter = current_filter(); // woocommerce_product_export_product_column_stock_<identifiant>
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			if ( substr( $filter, -strlen( '_stock_' . $wkey ) ) === '_stock_' . $wkey ) {
				$raw = get_post_meta( $product->get_id(), '_stock_' . $wkey, true );
				return '' === $raw ? '' : wc_format_decimal( $raw );
			}
		}
		return $value;
	}

	public function import_mapping_options( $options ) {
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$options[ 'stock_' . $wkey ] = sprintf( __( 'Stock %s', 'wc-multi-entrepot' ), $wlabel );
		}
		return $options;
	}

	public function import_default_columns( $columns ) {
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$columns[ sprintf( __( 'Stock %s', 'wc-multi-entrepot' ), $wlabel ) ] = 'stock_' . $wkey;
		}
		return $columns;
	}

	/** À l'import : enregistre les stocks d'entrepôt puis recalcule le stock global (= somme). */
	public function import_warehouse_stock( $product, $data ) {
		$this->busy = true;
		$post_id    = $product->get_id();
		$touched    = false;

		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$k = 'stock_' . $wkey;
			if ( ! isset( $data[ $k ] ) || '' === trim( (string) $data[ $k ] ) ) continue;

			$old = (float) get_post_meta( $post_id, '_stock_' . $wkey, true );
			$new = (float) wc_stock_amount( $data[ $k ] );
			update_post_meta( $post_id, '_stock_' . $wkey, $new );
			$this->log_change( $post_id, $wkey, $old, $new, 'import', 0, __( 'Import CSV', 'wc-multi-entrepot' ) );
			$touched = true;
		}

		if ( $touched ) {
			$this->sync_global_stock( $post_id );
		}
		$this->busy = false;
	}

	/* =====================================================================
	 * 9) ÉCRITURES EXTERNES (autre plugin d'import, API, etc.)
	 * ===================================================================== */

	private function is_warehouse_meta_key( $meta_key ) {
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			if ( '_stock_' . $wkey === $meta_key ) return $wkey;
		}
		return false;
	}

	/** Avant l'écriture : on retient l'ancienne valeur pour l'historique. */
	public function capture_old_value( $meta_id, $object_id, $meta_key, $meta_value ) {
		if ( $this->busy || false === $this->is_warehouse_meta_key( $meta_key ) ) return;
		$this->old_values[ $object_id . '|' . $meta_key ] = (float) get_post_meta( $object_id, $meta_key, true );
	}

	/** Après l'écriture par un autre plugin : on journalise et on programme la mise à jour du stock global. */
	public function on_external_meta_write( $meta_id, $object_id, $meta_key, $meta_value ) {
		if ( $this->busy ) return;

		$is_global = ( '_stock' === $meta_key );
		$wkey      = $this->is_warehouse_meta_key( $meta_key );
		if ( ! $is_global && false === $wkey ) return;

		if ( ! in_array( get_post_type( $object_id ), array( 'product', 'product_variation' ), true ) ) return;

		if ( $wkey ) {
			$id  = $object_id . '|' . $meta_key;
			$old = isset( $this->old_values[ $id ] ) ? $this->old_values[ $id ] : 0;
			unset( $this->old_values[ $id ] );
			$this->log_change( $object_id, $wkey, $old, (float) $meta_value, 'external', 0, __( 'Écriture directe du champ (import ou autre plugin)', 'wc-multi-entrepot' ) );
		}

		// Recalcul différé, tout à la fin de la requête : l'autre plugin a fini d'écrire tous ses champs,
		// y compris son propre "stock global" (qui est alors ré-aligné sur la somme des entrepôts).
		// Sans effet pour les produits sans stock d'entrepôt renseigné.
		$this->pending_sync[ (int) $object_id ] = true;
	}

	public function flush_pending_syncs() {
		if ( ! $this->pending_sync ) return;

		$ids                = array_keys( $this->pending_sync );
		$this->pending_sync = array();

		$this->busy = true;
		foreach ( $ids as $product_id ) {
			$this->sync_global_stock( $product_id );
		}
		$this->busy = false;
	}

	/* =====================================================================
	 * 10) RESYNCHRONISATION DU STOCK GLOBAL (bouton + vérification horaire)
	 * ===================================================================== */

	/** Produits dont le stock global WooCommerce ne correspond pas à la somme des entrepôts. */
	private function find_mismatched_products() {
		global $wpdb;

		if ( ! $this->sync_enabled() ) return array();

		$meta_keys = array();
		foreach ( $this->warehouses() as $wkey => $wlabel ) {
			$meta_keys[] = "'" . esc_sql( '_stock_' . $wkey ) . "'";
		}
		if ( ! $meta_keys ) return array();

		$ids = array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN (" . implode( ',', $meta_keys ) . ')' ) );
		if ( ! $ids ) return array();

		update_meta_cache( 'post', $ids );

		$bad = array();
		foreach ( $ids as $id ) {
			$filled = false;
			$sum    = 0;
			foreach ( $this->warehouses() as $wkey => $wlabel ) {
				$raw = get_post_meta( $id, '_stock_' . $wkey, true );
				if ( '' !== $raw ) $filled = true;
				$sum += (float) $raw;
			}
			if ( ! $filled ) continue;

			$global = get_post_meta( $id, '_stock', true );
			if ( '' === $global || (float) $global !== (float) $sum ) {
				$bad[] = $id;
			}
		}
		return $bad;
	}

	private function resync_all() {
		$ids = $this->find_mismatched_products();
		$this->busy = true;
		foreach ( $ids as $id ) {
			$this->sync_global_stock( $id );
		}
		$this->busy = false;
		return count( $ids );
	}

	public function handle_resync() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( esc_html__( 'Accès refusé.', 'wc-multi-entrepot' ) );
		check_admin_referer( 'wcme_resync' );

		if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 0 );
		$count = $this->resync_all();

		$page = ( isset( $_POST['wcme_back'] ) && 'settings' === $_POST['wcme_back'] ) ? 'wcme-settings' : 'wcme-history';
		wp_safe_redirect( add_query_arg( array( 'page' => $page, 'wcme_resynced' => $count ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * À l'ouverture de la liste des produits (ex. juste après un import), on corrige les écarts éventuels
	 * pour que la colonne « Stock » soit déjà juste. Limité à une vérification toutes les 30 secondes.
	 */
	public function maybe_resync_on_products_screen() {
		if ( ! isset( $_GET['post_type'] ) || 'product' !== $_GET['post_type'] ) return;
		if ( ! current_user_can( 'edit_products' ) || get_transient( 'wcme_recent_check' ) ) return;

		set_transient( 'wcme_recent_check', 1, 30 );
		$this->resync_all();
	}

	public function cron_reconcile() {
		$this->resync_all();
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'wcme_reconcile_cron' );
		wp_clear_scheduled_hook( 'wcme_purge_cron' );
	}

	/* =====================================================================
	 * 11) PAGE « ENTREPÔTS ET RÉGLAGES » (WooCommerce → Entrepôts)
	 * ===================================================================== */

	public function add_settings_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Entrepôts et réglages', 'wc-multi-entrepot' ),
			__( 'Entrepôts', 'wc-multi-entrepot' ),
			'manage_woocommerce',
			'wcme-settings',
			array( $this, 'render_settings_page' )
		);
	}

	/** Lien « Réglages » dans la liste des extensions. */
	public function plugin_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=wcme-settings' ) ) . '">' . esc_html__( 'Réglages', 'wc-multi-entrepot' ) . '</a>' );
		return $links;
	}

	private function push_notice( $type, $message ) {
		$key = 'wcme_notice_' . get_current_user_id();
		$all = get_transient( $key );
		if ( ! is_array( $all ) ) $all = array();
		$all[] = array( $type, $message );
		set_transient( $key, $all, 120 );
	}

	/** Pour chaque entrepôt : nombre de produits en stock et nombre total d'unités. */
	private function warehouse_stats() {
		global $wpdb;

		$out = array();
		foreach ( $this->warehouses() as $key => $label ) {
			$vals     = $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value <> ''", '_stock_' . $key ) );
			$units    = 0;
			$products = 0;
			foreach ( $vals as $v ) {
				$v = (float) $v;
				if ( $v > 0 ) {
					$units += $v;
					$products++;
				}
			}
			$out[ $key ] = array( 'units' => $units, 'products' => $products );
		}
		return $out;
	}

	private function orphan_meta_exists( $key ) {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key = %s LIMIT 1", '_stock_' . $key ) );
	}

	/** Identifiant technique (a-z, 0-9, _) généré à partir du nom, unique et jamais réutilisé. */
	private function make_key( $label, $existing ) {
		$key = strtolower( remove_accents( $label ) );
		$key = trim( preg_replace( '/[^a-z0-9]+/', '_', $key ), '_' );
		$key = substr( $key, 0, 16 );
		if ( '' === $key ) $key = 'entrepot';

		$reserved = array( 'status', 'global', 'total' ); // _stock_status est utilisé par WooCommerce
		$base     = $key;
		$n        = 2;
		while ( isset( $existing[ $key ] ) || in_array( $key, $reserved, true ) || $this->orphan_meta_exists( $key ) ) {
			$key = $base . '_' . $n;
			$n++;
		}
		return $key;
	}

	public function handle_save_warehouses() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( esc_html__( 'Accès refusé.', 'wc-multi-entrepot' ) );
		check_admin_referer( 'wcme_save_warehouses' );

		$current = $this->warehouses();
		$stats   = $this->warehouse_stats();
		$posted  = ( isset( $_POST['wh'] ) && is_array( $_POST['wh'] ) ) ? wp_unslash( $_POST['wh'] ) : array();

		$rows    = array();
		$idx     = 0;
		$deleted = 0;
		$max     = 0;
		$msgs    = array(); // confirmations affichées seulement si l'enregistrement réussit

		foreach ( $current as $key => $label ) {
			$p     = ( isset( $posted[ $key ] ) && is_array( $posted[ $key ] ) ) ? $posted[ $key ] : array();
			$name  = isset( $p['label'] ) ? sanitize_text_field( $p['label'] ) : $label;
			$name  = ( '' === $name ) ? $label : $name;
			$order = ( isset( $p['order'] ) && '' !== $p['order'] ) ? (int) $p['order'] : ( $idx + 1 ) * 10;
			$idx++;

			if ( ! empty( $p['delete'] ) ) {
				if ( count( $current ) - $deleted <= 1 ) {
					$this->push_notice( 'error', __( 'Impossible de supprimer le dernier entrepôt : il en faut au moins un.', 'wc-multi-entrepot' ) );
				} elseif ( $stats[ $key ]['units'] > 0 ) {
					$this->push_notice( 'error', sprintf( __( '« %s » n\'a pas été supprimé : il contient encore du stock. Transférez ou videz son stock d\'abord.', 'wc-multi-entrepot' ), $label ) );
				} else {
					$deleted++;
					$msgs[] = sprintf( __( 'Entrepôt « %s » supprimé.', 'wc-multi-entrepot' ), $label );
					continue;
				}
			}

			$rows[] = array( $key, $name, $order, $idx );
			$max    = max( $max, $order );
		}

		// Nouveaux entrepôts : un nom par ligne (on peut en créer plusieurs d'un coup).
		$new_raw   = isset( $_POST['new_label'] ) ? sanitize_textarea_field( wp_unslash( $_POST['new_label'] ) ) : '';
		$new_names = array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', $new_raw ) ), 'strlen' );
		foreach ( $new_names as $new ) {
			$new = sanitize_text_field( mb_substr( $new, 0, 60 ) );
			if ( '' === $new ) continue;

			$map = array();
			foreach ( $rows as $r ) $map[ $r[0] ] = $r[1];

			$max     += 10;
			$idx++;
			$new_key  = $this->make_key( $new, $map );
			$rows[]   = array( $new_key, $new, $max, $idx );
			$msgs[]   = sprintf( __( 'Entrepôt « %s » ajouté. Vous pouvez maintenant saisir son stock sur la fiche de chaque produit.', 'wc-multi-entrepot' ), $new );
		}

		// Refuser deux entrepôts de même nom.
		$seen = array();
		foreach ( $rows as $r ) {
			$low = strtolower( $r[1] );
			if ( isset( $seen[ $low ] ) ) {
				$this->push_notice( 'error', sprintf( __( 'Deux entrepôts portent le même nom (« %s »). Rien n\'a été enregistré.', 'wc-multi-entrepot' ), $r[1] ) );
				wp_safe_redirect( admin_url( 'admin.php?page=wcme-settings' ) );
				exit;
			}
			$seen[ $low ] = true;
		}

		usort( $rows, function ( $a, $b ) {
			return ( $a[2] === $b[2] ) ? ( $a[3] - $b[3] ) : ( $a[2] - $b[2] );
		} );

		$map = array();
		foreach ( $rows as $r ) $map[ $r[0] ] = $r[1];

		update_option( 'wcme_warehouses', $map );
		$this->wh_cache = null;

		foreach ( $msgs as $msg ) {
			$this->push_notice( 'success', $msg );
		}
		$this->push_notice( 'success', __( 'Les entrepôts ont été enregistrés.', 'wc-multi-entrepot' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=wcme-settings' ) );
		exit;
	}

	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( esc_html__( 'Accès refusé.', 'wc-multi-entrepot' ) );
		check_admin_referer( 'wcme_save_settings' );

		$was_sync = $this->sync_enabled();

		update_option( 'wcme_auto_transfer', ! empty( $_POST['auto_transfer'] ) ? 'yes' : 'no' );
		update_option( 'wcme_transfer_strategy', ( isset( $_POST['strategy'] ) && 'most' === $_POST['strategy'] ) ? 'most' : 'order' );
		update_option( 'wcme_sync_global', ! empty( $_POST['sync_global'] ) ? 'yes' : 'no' );

		$low = isset( $_POST['low_threshold'] ) ? trim( wp_unslash( $_POST['low_threshold'] ) ) : '';
		update_option( 'wcme_low_threshold', ( '' === $low || ! is_numeric( $low ) ) ? '' : (string) max( 0, (float) $low ) );

		$days = isset( $_POST['retention'] ) ? min( 3650, absint( $_POST['retention'] ) ) : 0;
		update_option( 'wcme_retention_days', $days );

		update_option( 'wcme_delete_on_uninstall', ! empty( $_POST['delete_data'] ) ? 'yes' : 'no' );

		$this->push_notice( 'success', __( 'Réglages enregistrés.', 'wc-multi-entrepot' ) );

		// Le suivi du stock global vient d'être activé : on aligne tous les produits tout de suite.
		if ( ! $was_sync && $this->sync_enabled() ) {
			if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 0 );
			$count = $this->resync_all();
			$this->push_notice( 'success', sprintf( __( 'Stock global aligné sur la somme des entrepôts pour %d produit(s).', 'wc-multi-entrepot' ), $count ) );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=wcme-settings' ) );
		exit;
	}

	/** Supprime les lignes d'historique plus anciennes que la durée de conservation choisie. */
	public function cron_purge_history() {
		$days = (int) get_option( 'wcme_retention_days', 0 );
		if ( $days <= 0 ) return;

		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE created_at < %s', gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ) );
	}

	public function render_settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) return;

		$warehouses = $this->warehouses();
		$stats      = $this->warehouse_stats();
		$total_wh   = count( $warehouses );
		$mismatch   = $this->sync_enabled() ? count( $this->find_mismatched_products() ) : 0;

		echo '<div class="wrap wcme-settings"><h1>' . esc_html__( 'Entrepôts et réglages', 'wc-multi-entrepot' ) . '</h1>';

		// Messages mémorisés (après enregistrement).
		$nkey    = 'wcme_notice_' . get_current_user_id();
		$notices = get_transient( $nkey );
		if ( is_array( $notices ) ) {
			foreach ( $notices as $n ) {
				echo '<div class="notice notice-' . esc_attr( $n[0] ) . ' is-dismissible"><p>' . esc_html( $n[1] ) . '</p></div>';
			}
			delete_transient( $nkey );
		}
		if ( isset( $_GET['wcme_resynced'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( __( 'Resynchronisation terminée : %d produit(s) mis à jour.', 'wc-multi-entrepot' ), absint( $_GET['wcme_resynced'] ) ) ) . '</p></div>';
		}

		echo '<style>
			.wcme-settings .wcme-card { background:#fff; border:1px solid #c3c4c7; border-radius:4px; padding:16px 20px; margin:16px 0; max-width:980px; }
			.wcme-settings .wcme-card h2 { margin-top:0; }
			.wcme-settings code { background:#f0f0f1; padding:2px 6px; border-radius:3px; }
			.wcme-settings .form-table th { width:260px; }
			.wcme-settings td input[type=number] { width:80px; }
			.wcme-settings .wcme-muted { color:#646970; }
		</style>';

		/* ---------- 1) Entrepôts ---------- */
		echo '<div class="wcme-card"><h2>' . esc_html__( '1. Vos entrepôts', 'wc-multi-entrepot' ) . '</h2>';
		echo '<p class="wcme-muted">' . esc_html__( 'Ajoutez, renommez ou réordonnez vos entrepôts. Chaque entrepôt apparaît automatiquement sur la fiche produit, sur les commandes, dans la liste des produits, dans l\'historique et dans les exports.', 'wc-multi-entrepot' ) . '</p>';

		if ( ! $warehouses ) {
			echo '<div class="notice notice-info inline"><p><strong>' . esc_html__( 'Bienvenue !', 'wc-multi-entrepot' ) . '</strong> '
				. esc_html__( 'Aucun entrepôt n\'existe encore. Saisissez ci-dessous le nom de vos entrepôts (un par ligne), puis cliquez sur « Enregistrer les entrepôts ». Vous pourrez ensuite renseigner le stock de chaque entrepôt sur vos fiches produit.', 'wc-multi-entrepot' ) . '</p></div>';
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="wcme-wh-form">';
		echo '<input type="hidden" name="action" value="wcme_save_warehouses">';
		wp_nonce_field( 'wcme_save_warehouses' );

		if ( ! $warehouses ) {
			echo '<p><textarea name="new_label" rows="4" class="large-text" style="max-width:420px;" placeholder="' . esc_attr__( "Ex. :\nEntrepôt principal\nBoutique centre-ville\nDépôt Nord", 'wc-multi-entrepot' ) . '"></textarea></p>';
		} else {
		echo '<table class="widefat striped"><thead><tr>';
		echo '<th style="width:70px;">' . esc_html__( 'Ordre', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Nom de l\'entrepôt', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Identifiant', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Produits en stock', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Unités en stock', 'wc-multi-entrepot' ) . '</th>';
		echo '<th>' . esc_html__( 'Supprimer', 'wc-multi-entrepot' ) . '</th>';
		echo '</tr></thead><tbody>';

		$i = 0;
		foreach ( $warehouses as $key => $label ) {
			$i++;
			$can_delete = ( $total_wh > 1 && $stats[ $key ]['units'] <= 0 );
			echo '<tr>';
			printf( '<td><input type="number" min="0" name="wh[%s][order]" value="%d"></td>', esc_attr( $key ), $i * 10 );
			printf( '<td><input type="text" class="regular-text" name="wh[%s][label]" value="%s"></td>', esc_attr( $key ), esc_attr( $label ) );
			echo '<td><code>_stock_' . esc_html( $key ) . '</code></td>';
			echo '<td>' . esc_html( $stats[ $key ]['products'] ) . '</td>';
			echo '<td>' . esc_html( wc_format_decimal( $stats[ $key ]['units'] ) ) . '</td>';
			echo '<td>';
			if ( $can_delete ) {
				printf( '<label><input type="checkbox" class="wcme-del" name="wh[%s][delete]" value="1"> %s</label>', esc_attr( $key ), esc_html__( 'Supprimer', 'wc-multi-entrepot' ) );
			} else {
				echo '<span class="wcme-muted" title="' . esc_attr__( 'Un entrepôt ne peut être supprimé que s\'il est vide (et s\'il en reste un autre).', 'wc-multi-entrepot' ) . '">—</span>';
			}
			echo '</td></tr>';
		}

		echo '<tr><td></td><td colspan="5"><textarea name="new_label" rows="2" class="large-text" style="max-width:420px;" placeholder="' . esc_attr__( 'Nouvel entrepôt (un nom par ligne pour en ajouter plusieurs)', 'wc-multi-entrepot' ) . '"></textarea> ';
		echo '<span class="wcme-muted">' . esc_html__( 'Laissez vide pour ne rien ajouter.', 'wc-multi-entrepot' ) . '</span></td></tr>';
		echo '</tbody></table>';
		}

		echo '<p><button class="button button-primary">' . esc_html__( 'Enregistrer les entrepôts', 'wc-multi-entrepot' ) . '</button> ';
		echo '<span class="wcme-muted">' . esc_html__( 'L\'ordre sert aussi à choisir l\'entrepôt qui réapprovisionne les autres (voir réglages).', 'wc-multi-entrepot' ) . '</span></p>';
		echo '</form>';
		echo '<script>document.getElementById("wcme-wh-form").addEventListener("submit",function(e){if(document.querySelector(".wcme-del:checked")&&!confirm(' . wp_json_encode( __( 'Supprimer définitivement les entrepôts cochés ?', 'wc-multi-entrepot' ) ) . ')){e.preventDefault();}});</script>';
		echo '</div>';

		/* ---------- 2) Réglages ---------- */
		$auto     = ( 'yes' === get_option( 'wcme_auto_transfer', 'yes' ) );
		$strategy = $this->transfer_strategy();
		$sync     = $this->sync_enabled();
		$low      = get_option( 'wcme_low_threshold', '' );
		$days     = (int) get_option( 'wcme_retention_days', 0 );
		$del      = ( 'yes' === get_option( 'wcme_delete_on_uninstall', 'no' ) );

		echo '<div class="wcme-card"><h2>' . esc_html__( '2. Réglages', 'wc-multi-entrepot' ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="wcme_save_settings">';
		wp_nonce_field( 'wcme_save_settings' );
		echo '<table class="form-table" role="presentation"><tbody>';

		echo '<tr><th scope="row">' . esc_html__( 'Stock global', 'wc-multi-entrepot' ) . '</th><td><label><input type="checkbox" name="sync_global" value="1" ' . checked( $sync, true, false ) . '> ' . esc_html__( 'Calculer automatiquement le stock global WooCommerce = somme des stocks des entrepôts', 'wc-multi-entrepot' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Conseillé. Si vous décochez, le stock global n\'est plus modifié par le plugin (vous le gérez à la main).', 'wc-multi-entrepot' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Réapprovisionnement automatique', 'wc-multi-entrepot' ) . '</th><td><label><input type="checkbox" name="auto_transfer" value="1" ' . checked( $auto, true, false ) . '> ' . esc_html__( 'Si le stock d\'un entrepôt ne suffit pas pour une commande, prendre le manque dans un autre entrepôt', 'wc-multi-entrepot' ) . '</label></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Entrepôt qui réapprovisionne', 'wc-multi-entrepot' ) . '</th><td>';
		echo '<label><input type="radio" name="strategy" value="order" ' . checked( $strategy, 'order', false ) . '> ' . esc_html__( 'Selon l\'ordre de la liste ci-dessus (le premier en premier)', 'wc-multi-entrepot' ) . '</label><br>';
		echo '<label><input type="radio" name="strategy" value="most" ' . checked( $strategy, 'most', false ) . '> ' . esc_html__( 'L\'entrepôt qui a le plus de stock de ce produit', 'wc-multi-entrepot' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Utile à partir de trois entrepôts.', 'wc-multi-entrepot' ) . '</p></td></tr>';

		echo '<tr><th scope="row"><label for="wcme_low">' . esc_html__( 'Seuil « stock bas »', 'wc-multi-entrepot' ) . '</label></th><td><input type="number" min="0" step="1" id="wcme_low" name="low_threshold" value="' . esc_attr( $low ) . '" placeholder="' . esc_attr( (float) get_option( 'woocommerce_notify_low_stock_amount', 2 ) ) . '"> ';
		echo '<p class="description">' . esc_html__( 'Quantité à partir de laquelle un stock d\'entrepôt s\'affiche en orange dans la liste des produits. Vide = seuil de WooCommerce.', 'wc-multi-entrepot' ) . '</p></td></tr>';

		echo '<tr><th scope="row"><label for="wcme_ret">' . esc_html__( 'Conservation de l\'historique', 'wc-multi-entrepot' ) . '</label></th><td><input type="number" min="0" max="3650" id="wcme_ret" name="retention" value="' . esc_attr( $days ) . '"> ' . esc_html__( 'jours', 'wc-multi-entrepot' );
		echo '<p class="description">' . esc_html__( '0 = conserver indéfiniment. Sinon, les mouvements plus anciens sont supprimés automatiquement chaque jour.', 'wc-multi-entrepot' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'À la suppression du plugin', 'wc-multi-entrepot' ) . '</th><td><label><input type="checkbox" name="delete_data" value="1" ' . checked( $del, true, false ) . '> ' . esc_html__( 'Supprimer aussi les stocks par entrepôt, l\'affectation des commandes et l\'historique', 'wc-multi-entrepot' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Laissé décoché, vos données sont conservées si vous désinstallez puis réinstallez le plugin.', 'wc-multi-entrepot' ) . '</p></td></tr>';

		echo '</tbody></table>';
		echo '<p><button class="button button-primary">' . esc_html__( 'Enregistrer les réglages', 'wc-multi-entrepot' ) . '</button></p>';
		echo '</form></div>';

		/* ---------- 3) Outils ---------- */
		echo '<div class="wcme-card"><h2>' . esc_html__( '3. Outils', 'wc-multi-entrepot' ) . '</h2>';
		if ( $sync ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;">';
			echo '<input type="hidden" name="action" value="wcme_resync"><input type="hidden" name="wcme_back" value="settings">';
			wp_nonce_field( 'wcme_resync' );
			echo '<span>' . ( $mismatch
				? esc_html( sprintf( __( '%d produit(s) ont un stock global différent de la somme des entrepôts.', 'wc-multi-entrepot' ), $mismatch ) )
				: esc_html__( 'Le stock global de tous les produits correspond à la somme des entrepôts.', 'wc-multi-entrepot' ) ) . '</span>';
			echo '<button class="button">' . esc_html__( 'Resynchroniser le stock global de tous les produits', 'wc-multi-entrepot' ) . '</button>';
			echo '</form>';
		}
		echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=wcme-history' ) ) . '">' . esc_html__( 'Voir l\'historique des mouvements de stock', 'wc-multi-entrepot' ) . '</a></p>';
		echo '</div>';

		echo '</div>';
	}

	/* =====================================================================
	 * 6) COLONNE "ENTREPÔT" DANS LA LISTE DES COMMANDES
	 * ===================================================================== */

	public function add_order_column( $columns ) {
		$new = array();
		foreach ( $columns as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'order_status' === $key ) {
				$new['wcme_entrepot'] = __( 'Entrepôt', 'wc-multi-entrepot' );
			}
		}
		return $new;
	}

	public function render_order_column( $column, $post_id_or_order ) {
		if ( 'wcme_entrepot' !== $column ) return;
		$order = ( $post_id_or_order instanceof WC_Order ) ? $post_id_or_order : wc_get_order( $post_id_or_order );
		if ( ! $order ) return;
		$warehouse = $order->get_meta( '_entrepot_choisi' );
		echo $warehouse ? esc_html( $this->wh_label( $warehouse ) ) : '—';
	}
}

register_activation_hook( __FILE__, array( 'WC_Multi_Entrepot', 'on_activate' ) );
register_deactivation_hook( __FILE__, array( 'WC_Multi_Entrepot', 'deactivate' ) );

new WC_Multi_Entrepot();
